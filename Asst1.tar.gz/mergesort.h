
#ifndef mergesort_h
#define mergesort_h

#include "simpleCSVsorter.h"

void merge(csventry* entryArr, int low, int mid, int high, int colID, int numeric);


#endif /* mergesort_h */

